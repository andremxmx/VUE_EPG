#!/usr/bin/env node

/**
##################################
####  O11 SCRAPER MODIFIED    ####
##################################
**/

console.log(`
##################################
####    O11 SCRAPER V3        ####
####  DEVELOPED BY STRIXDEV   ####
##################################
`);

const { Builder, By, until } = require('selenium-webdriver');
const firefox = require('selenium-webdriver/firefox');
const fs = require('fs');
const path = require('path');
const readline = require('readline');

const downloadResults = [];
let processedServers = 0;
let totalServers = 0;

// Progress bar function
const updateProgressBar = () => {
  const progressPercent = Math.floor((processedServers / totalServers) * 100);
  const progressBarLength = 30;
  const filledLength = Math.floor((progressPercent * progressBarLength) / 100);
  const progressBar = '█'.repeat(filledLength) + '░'.repeat(progressBarLength - filledLength);
  
  process.stdout.write(`\r[${progressBar}] ${progressPercent}% | Processed: ${processedServers}/${totalServers} servers`);
  
  if (processedServers === totalServers) {
    process.stdout.write('\n');
  }
};

// Create a readline interface for user input
const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout
});

// Process server function (defined here to avoid duplication)
const processServer = async (driver, server) => {
  try {
    const serverUrl = `http://${server.ip}:${server.port}/`;
    
    // Attempt to connect to server
    await driver.get(serverUrl);

    // Wait for elements to load and get their data
    const elements = await driver.wait(until.elementsLocated(By.css('div.img-with-text')), 15000);
    const data = await Promise.all(elements.map(async (element) => {
      const text = await element.getText();
      const link = await element.findElement(By.css('a')).getAttribute('href');
      return { text: text.trim().replace(/\s+/g, ' '), link };
    }));

    if (data.length === 0) {
      // If no data found, just increment counter without output
      processedServers++;
      updateProgressBar();
      return;
    }

    const newData = data.map(item => {
      const configLink = item.link.replace('/status/', '/config/');
      return { ...item, config: configLink };
    });

    let downloadCount = 0;
    for (const item of newData) {
      try {
        await driver.get(item.config);
        
        // Wait for and click the export button
        const exportButton = await driver.wait(until.elementLocated(By.css('#exportprovider')), 15000);
        await exportButton.click();
        await new Promise(resolve => setTimeout(resolve, 5000)); // Wait for download

        // Add download info to results
        downloadResults.push({
          filename: `${item.text}.cfg`,
          server_ip: server.ip,
          server_port: server.port,
          country: server.country
        });
        
        downloadCount++;
      } catch (error) {
        // Silent error handling
      }
    }
    
    if (downloadCount > 0) {
      process.stdout.write(`\r${' '.repeat(80)}`); // Clear current line
      console.log(`Downloaded ${downloadCount} config(s) from ${server.ip}:${server.port}`);
    }
    
  } catch (error) {
    // Silent error handling for server access errors
  } finally {
    // Always increment processed count
    processedServers++;
    updateProgressBar();
  }
};

// Main function
(async () => {
  // Read the list of IPs from local ips.txt file
  let servers = [];
  try {
    const fileContent = fs.readFileSync('ips.txt', 'utf8');
    const lines = fileContent.split('\n').filter(line => line.trim() !== '');
    
    // Skip header if exists
    const startIndex = lines[0].toLowerCase() === 'host' ? 1 : 0;
    
    for (let i = startIndex; i < lines.length; i++) {
      const line = lines[i].trim();
      if (!line) continue;
      
      const [ip, port] = line.split(':');
      if (ip && port) {
        servers.push({
          ip,
          port,
          country: 'Unknown' // Since we don't have country info in the local file
        });
      }
    }
    
    totalServers = servers.length;
    console.log(`Loaded ${totalServers} servers from ips.txt`);
  } catch (error) {
    console.error('Error reading ips.txt file:', error);
    process.exit(1);
  }

  // Ask user for the number of concurrent tasks
  rl.question('How many concurrent tasks do you want to run (1-5)? ', async (answer) => {
    let concurrentTasks = parseInt(answer, 10);
    
    // Validate input
    if (isNaN(concurrentTasks) || concurrentTasks < 1 || concurrentTasks > 5) {
      console.log('Invalid input. Using default value of 1 task.');
      concurrentTasks = 1;
    }
    
    console.log(`Running with ${concurrentTasks} concurrent tasks`);
    console.log('Starting scraping process...');
    rl.close();

    // Initialize progress bar
    updateProgressBar();

    // Configure Firefox options
    const options = new firefox.Options();
    options.setPreference('browser.download.folderList', 2);
    options.setPreference('browser.download.dir', process.cwd());
    options.setPreference('browser.helperApps.neverAsk.saveToDisk', 'application/octet-stream');

    // Initialize an array to store the driver instances
    const drivers = [];
    for (let i = 0; i < concurrentTasks; i++) {
      const driver = await new Builder()
        .forBrowser('firefox')
        .setFirefoxOptions(options)
        .build();
      drivers.push(driver);
    }

    try {
      // Process servers in chunks based on the number of concurrent tasks
      for (let i = 0; i < servers.length; i += concurrentTasks) {
        const tasks = [];
        
        // Create a batch of promises for concurrent execution
        for (let j = 0; j < concurrentTasks && i + j < servers.length; j++) {
          const server = servers[i + j];
          const driver = drivers[j];
          tasks.push(processServer(driver, server));
        }
        
        // Wait for all tasks in the current batch to complete
        await Promise.all(tasks);
      }

      // Save download results to JSON file
      const resultsJson = JSON.stringify(downloadResults, null, 2);
      const resultsPath = path.join(process.cwd(), 'download_results.json');
      fs.writeFileSync(resultsPath, resultsJson);
      console.log(`\nCompleted! Downloaded ${downloadResults.length} configuration files.`);
      console.log(`Results saved to ${resultsPath}`);

    } catch (error) {
      console.error(`\nError processing servers: ${error}`);
    } finally {
      // Quit all driver instances
      for (const driver of drivers) {
        await driver.quit();
      }
    }
  });
})();